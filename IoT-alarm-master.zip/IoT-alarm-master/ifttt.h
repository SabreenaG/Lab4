int ifttt(char*where, char *v1, char *v2, char *v3);
